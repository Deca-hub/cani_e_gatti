import csv;
import os

def menu_taglia():
    contatore = 0
    legenda = "\n"
    for line in lines:
        if contatore > 0 and contatore < 4:
            legenda = legenda + ("[" + str(contatore) + "]" + line.split(",")[0]) + "\n"
        contatore = contatore + 1

    taglia = 0;
    while ((taglia < 1) or (taglia  > 3)):
        clear()
        print(legenda)
        taglia = int(input("inserisci il numero corrispettivo alla taglia desiderata: "))
    return taglia

def filtra_taglia(taglia):
    f = open("C:/uni/progetto_simone (3)/progetto_simone/cani.txt")
    lines = f.readlines()
    filtrato = [""] * 25
    count = 0
    elemento = 0
    taglia = taglia
    for line in lines:
        if taglia == count:
            counter = 0
            for word in line.split(","):
                word = word.strip()
                if word == "si":
                    filtrato[elemento] = (lines[0].split(",")[counter])
                    elemento = elemento +1
                counter = counter + 1
            return filtrato;

        count = count +1;
    return filtrato

def menu_specifiche():
    contatore = 0
    legenda = "\n"
    for line in lines:
        if contatore > 3 and contatore < count_lines:
            legenda = legenda + ("[" + str(contatore - 4) + "]" + line.split(",")[0]) + "\n"
        contatore = contatore + 1
    specifica = 0;
    while ((specifica < 1) or (specifica  > count_lines - 4)):
        clear()
        print(legenda)
        specifica = int(input("inserisci il numero corrispettivo alla specifica desiderata: "))
    return specifica + 4


def filtra_specifica(specif):
    f = open("C:/uni/progetto_simone (3)/progetto_simone/cani.txt")
    lines = f.readlines()
    filtrato = [""] * 25
    count = 0
    elemento = 0
    specif = specif
    for line in lines:
        if specif == count:
            counter = 0
            for word in line.split(","):
                word = word.strip()
                if word == "si":
                    filtrato[elemento] = (lines[0].split(",")[counter])
                    elemento = elemento + 1
                counter = counter + 1
            return filtrato;

        count = count + 1;
    return filtrato

def print_list(list):
    lista = ""
    acapo = 0
    for el in list:
        if el != "":
            lista = lista + el +" "
            if acapo == 4:
                lista = lista +"\n"
                acapo = 0
            acapo += 1
    print (lista + "\n")
def unisci_liste(lista1, lista2):
    lista = []
    for elem1 in lista1:
        for elem2 in lista2:
            if elem1 == elem2:
                lista.append(elem1)
    return lista;

if __name__ == '__main__':
    clear = lambda: os.system('cls')
    f = open("C:/uni/progetto_simone (3)/progetto_simone/cani.txt")
    count_lines = 0;
    lines = f.readlines();
    for line in lines:
        count_lines = count_lines +1 


    taglia = menu_taglia()
    filtrato_tagliato = []
    filtrato_tagliato = filtra_taglia(taglia)
    print_list (filtrato_tagliato)
    specif = menu_specifiche()
    filtrato_specificato = []
    filtrato_specificato = filtra_specifica(specif)
    print_list(filtrato_specificato)
    lista_finale = unisci_liste(filtrato_tagliato, filtrato_specificato)
    print("i croccantini adatti ad entrambe le specifiche sono:")
    print_list(lista_finale)
