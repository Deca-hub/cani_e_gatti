import PySimpleGUI as psg
import os


def get_size_list():
    f = open("./cani.txt")
    list = []
    lines = f.readlines()
    cont = 0
    for line in lines:
        if cont > 0 and cont < 4:
            list.append(line.split(",")[0])
        cont += 1
    return list


def get_spec_list():
    f = open("./cani.txt")
    list = []
    lines = f.readlines()
    cont = 0
    for line in lines:
        if cont > 3:
            list.append(line.split(",")[0])
        cont += 1
    return list


def get_croccantini_stringa():
    list = get_croccantini()
    stringa = ""
    cont = 0
    for el in list:
        stringa = stringa + " " + el
        if cont % 4 == 0:
            stringa = stringa + "\n"
        cont += 1
    return stringa


def get_croccantini():
    f = open("./cani.txt")
    list = []
    lines = f.readlines()
    cont = 0
    for word in lines[0].split(','):
        if cont > 0:
            list.append(word)
        cont += 1

    return list


def check_filter(parola, filter):
    if parola in filter:
        return True
    return False


def filtra(filter):
    list = get_croccantini()
    f = open("./cani.txt")
    lines = f.readlines()
    for line in lines:
        if check_filter(line.split(",")[0], filter):
            count = -1
            for word in line.split(","):

                word = word.strip()
                if word == "no":
                    list[count] = "no"
                count += 1
    stringa = ""
    cont = 0
    for el in list:
        if el != "no":
            stringa = stringa + " " + el
            if cont % 4 == 0:
                stringa = stringa + "\n"
            cont += 1
    return stringa


def filtri_attuali(filter):
    stringa = "I filtri attuali sono : "
    for el in filter:
        stringa = stringa + el +", "
    return stringa


if __name__ == '__main__':
    crocca = get_croccantini_stringa()
    taglia = get_size_list()
    taglia.insert(0, "tutte le taglie")
    specifica = get_spec_list()
    specifica.insert(0, "tutte le specifiche")
    filter = ["tutte le taglie", "tutte le specifiche"]
    crocca = filtra(filter)
    menu_def = [['Taglia', taglia], ['Specifiche', specifica]]
    layout = [[psg.Menu(menu_def)],
              [psg.Text("I filtri attuali sono : tutte le taglie, tutte le specifiche", key='-FLTR-', expand_x=True, font=("Arial Bold", 14))],
              [psg.Text(crocca, key='-TXT-',
                        expand_x=True, font=("Arial Bold", 14))]
              ]
    window = psg.Window("Menu", layout, size=(715, 300))
    while True:
        event, values = window.read()

        if event in taglia:
            filter[0] = event
            window['-FLTR-'].update("I filtri attuali sono : " + filter[0] + ", " + filter[1])
            window['-TXT-'].update(filtra(filter))
        if event in specifica:
            if filter[1] == "tutte le specifiche":
                filter[1] = event
            else:
                filter.append(event)
            window['-FLTR-'].update(filtri_attuali(filter))
            window['-TXT-'].update(filtra(filter))
        if event == "tutte le taglie":
            filter[0] = "tutte le taglie"
            window['-FLTR-'].update(filtri_attuali(filter))
            window['-TXT-'].update(filtra(filter))
        if event == "tutte le specifiche":
            filtri = [filter[0], event]
            filter = filtri
            window['-FLTR-'].update(filtri_attuali(filter))
            window['-TXT-'].update(filtra(filter))
        if event == psg.WIN_CLOSED:
            break

        print(event, values, filter)
    window.close()
